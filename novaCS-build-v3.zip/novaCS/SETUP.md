# NovaCS — Setup Guide
## From zero to live in 6 steps

---

## Step 1 — Supabase Project

1. Go to **supabase.com** → Sign up / Sign in
2. Click **New project**
3. Fill in:
   - Name: `novaCS`
   - Database password: generate a strong one and **save it in a password manager**
   - Region: `West EU (Ireland)` — or closest to your users
   - Plan: Free (fine to start)
4. Wait ~2 minutes for provisioning
5. Go to **Project Settings → API**
6. Copy and save these two values:
   - `Project URL` → e.g. `https://abcdefgh.supabase.co`
   - `anon public` key → long JWT string starting with `eyJ...`
   - ⛔ DO NOT copy the `service_role` key anywhere in your frontend

---

## Step 2 — Run the Database Schema

1. In Supabase dashboard → **SQL Editor** → **New query**
2. Open `supabase/schema.sql` from this project
3. Paste the entire contents into the SQL editor
4. Click **Run** (RLS, tables, functions, triggers all created in one go)
5. Verify in **Table Editor** — you should see:
   - `organisations`
   - `recruiter_profiles`
   - `assessment_configs`
   - `candidates`
   - `access_codes`
   - `assessment_sessions`
   - `session_answers`
   - `invite_batches`
   - `contact_enquiries`
   - `audit_log`

---

## Step 3 — Create Your First Recruiter Account

1. In Supabase → **Authentication → Users** → **Invite user**
2. Enter your email address
3. Check your email and set your password via the link
4. Back in **SQL Editor**, run this to create the recruiter profile:

```sql
-- Replace the values below with your actual user ID and details
-- Find your user ID in Authentication → Users
INSERT INTO recruiter_profiles (id, organisation_id, full_name, email, role)
VALUES (
  'YOUR_AUTH_USER_ID_HERE',
  '00000000-0000-0000-0000-000000000001',  -- NovaCS org ID from seed data
  'Your Full Name',
  'your@email.com',
  'superadmin'
);
```

---

## Step 4 — GitHub Setup

1. Create a new **private** repository on GitHub named `novaCS`
2. In your project folder, open a terminal:

```bash
git init
git add .
git commit -m "Initial NovaCS build"
git branch -M main
git remote add origin https://github.com/YOURUSERNAME/novaCS.git
git push -u origin main
```

3. Double-check that `.env` is NOT in the commit:
```bash
git status  # should not show .env
```

---

## Step 5 — Vercel Deployment

1. Go to **vercel.com** → Sign in with GitHub
2. Click **Add New Project**
3. Import your `novaCS` repository
4. In **Environment Variables**, add:

| Variable Name         | Value                              |
|-----------------------|------------------------------------|
| `SUPABASE_URL`        | `https://yourproject.supabase.co`  |
| `SUPABASE_ANON_KEY`   | `eyJ...your anon key...`           |

   ⛔ Do NOT add `SUPABASE_SERVICE_ROLE_KEY` here or anywhere in frontend

5. Click **Deploy**
6. Your site is live at `https://your-project.vercel.app`

---

## Step 6 — Supabase Auth Settings

1. In Supabase → **Authentication → URL Configuration**
2. Set **Site URL** to your Vercel URL:
   `https://your-project.vercel.app`
3. Add **Redirect URLs**:
   - `https://your-project.vercel.app/pages/password-reset.html`
   - `https://your-project.vercel.app/index.html`
4. In **Authentication → Email Templates**, customise the:
   - Confirm signup email
   - Reset password email
   (Add NovaCS branding and your contact email)

---

## Security Checklist — Before Going Live

- [ ] `.env` file is in `.gitignore` and NOT committed to GitHub
- [ ] `service_role` key is never in any frontend file
- [ ] Supabase RLS is enabled on all tables (verify in Table Editor → each table → RLS tab)
- [ ] Vercel environment variables are set (not hardcoded in code)
- [ ] Supabase Auth → Site URL matches your production domain
- [ ] Password reset redirect URL is set correctly
- [ ] Custom domain added to Vercel (optional but recommended for trust)
- [ ] All HTML pages load via `api/env.js` for environment variables

---

## How the Security Works

```
Browser (Anon Key + RLS)
    │
    ├── Can INSERT contact_enquiries (public form)
    ├── Can call RPC: validate_access_code (returns minimal data)
    ├── Can call RPC: verify_candidate_identity (no direct table access)
    ├── Can call RPC: submit_assessment (SECURITY DEFINER writes results)
    │
    └── Authenticated Recruiter (JWT + RLS)
            │
            ├── SELECT candidates WHERE org = their_org ONLY
            ├── SELECT access_codes WHERE org = their_org ONLY
            ├── SELECT sessions WHERE org = their_org ONLY
            ├── UPDATE candidates (decision, stage, notes)
            └── No access to other orgs' data — ever

Service Role Key (NEVER in frontend)
    └── Only used in Supabase Edge Functions / Admin panel
```

---

## Local Development (Optional)

If you want to run locally before deploying:

1. Create `.env.local` in project root:
```
SUPABASE_URL=https://yourproject.supabase.co
SUPABASE_ANON_KEY=your_anon_key
```

2. Serve locally with any static server:
```bash
npx serve .
# or
python3 -m http.server 3000
```

3. Open `http://localhost:3000`

---

## Resend — Email Setup (Optional but Recommended)

For sending real invite emails and password resets:

1. Sign up at **resend.com** (free tier: 3000 emails/month)
2. Add your domain and verify DNS records
3. Create an API key
4. In Supabase → **Project Settings → Auth → SMTP Settings**:
   - Host: `smtp.resend.com`
   - Port: `465`
   - Username: `resend`
   - Password: your Resend API key
   - Sender email: `no-reply@yourdomain.com`
