/* ═══════════════════════════════════════════════════════════════
   NovaCS — Environment Variable Injection
   api/env.js  (Vercel serverless function)

   Serves public env vars to the frontend safely.
   Only NEXT_PUBLIC_ or explicitly allowlisted vars are exposed.
   The service_role key is NEVER included here.
═══════════════════════════════════════════════════════════════ */

export default function handler(req, res) {
  // Only GET allowed
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Only expose the anon key — this is safe by design
  // The anon key is limited by RLS policies on Supabase
  res.setHeader('Cache-Control', 'public, max-age=3600'); // cache 1hr
  res.setHeader('Content-Type', 'application/javascript');

  res.status(200).send(`
    window.__ENV = {
      SUPABASE_URL:      "${process.env.SUPABASE_URL || ''}",
      SUPABASE_ANON_KEY: "${process.env.SUPABASE_ANON_KEY || ''}"
    };
  `);
}
