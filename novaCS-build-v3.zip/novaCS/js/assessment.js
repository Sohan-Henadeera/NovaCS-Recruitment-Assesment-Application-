/* ═══════════════════════════════════════════════════════════════
   NovaCS — Assessment Module
   js/assessment.js

   Handles the applicant-side assessment flow.
   Applicants are NOT Supabase auth users.
   All writes go through SECURITY DEFINER RPC functions.
   The anon key + RLS prevents applicants reading any other data.
═══════════════════════════════════════════════════════════════ */

import { supabase } from './supabase-client.js';

// ── VALIDATE ACCESS CODE ──
// Step 1 of applicant login — check code exists and is active
export async function validateCode(orgSlug, code) {
  if (!code || code.length !== 6) return { valid: false, reason: 'invalid_format' };

  // We use an RPC function so we don't expose the access_codes table directly
  const { data, error } = await supabase.rpc('validate_access_code', {
    p_org_slug: orgSlug.toLowerCase(),
    p_code:     code.toUpperCase().trim()
  });

  if (error || !data) return { valid: false, reason: 'not_found' };
  if (data.status === 'used')     return { valid: false, reason: 'already_used' };
  if (data.status === 'revoked')  return { valid: false, reason: 'revoked' };
  if (data.status === 'expired')  return { valid: false, reason: 'expired' };

  // Check expiry date if set
  if (data.expires_at && new Date(data.expires_at) < new Date()) {
    return { valid: false, reason: 'expired' };
  }

  return { valid: true, candidateId: data.candidate_id, codeId: data.id };
}


// ── VERIFY IDENTITY ──
// Step 2 — check name, email, phone_last4 match the candidate record
export async function verifyIdentity(candidateId, { full_name, email, phone_last4 }) {
  const { data, error } = await supabase.rpc('verify_candidate_identity', {
    p_candidate_id: candidateId,
    p_full_name:    full_name.trim(),
    p_email:        email.trim().toLowerCase(),
    p_phone_last4:  phone_last4.trim()
  });

  if (error) return { verified: false };

  // RPC returns attempt count — lock after 3 failures
  if (!data.verified) {
    return {
      verified:  false,
      attempts:  data.attempts_used,
      locked:    data.attempts_used >= 3,
    };
  }

  return { verified: true, sessionToken: data.session_token };
}


// ── CREATE ASSESSMENT SESSION ──
// Called after identity is verified
export async function createSession(candidateId, codeId, orgId) {
  const { data, error } = await supabase.rpc('create_assessment_session', {
    p_candidate_id:    candidateId,
    p_access_code_id:  codeId,
    p_organisation_id: orgId,
    p_user_agent:      navigator.userAgent.substring(0, 200),
  });

  if (error) throw new Error('Failed to create session');
  return data; // returns session_id
}


// ── RECORD TAB SWITCH ──
// Called when applicant switches away from the assessment tab
export async function recordTabSwitch(sessionId) {
  await supabase.rpc('record_tab_switch', { p_session_id: sessionId });
}


// ── SUBMIT ASSESSMENT ──
// Final submission — all answers, scores, timing
export async function submitAssessment(sessionId, payload) {
  const {
    answers,           // array of { question_id, category, answer_given, is_correct, time_spent_ms }
    score_judgement,
    score_numerical,
    score_verbal,
    score_situational,
    time_taken_seconds,
  } = payload;

  // Basic validation
  if (!sessionId) throw new Error('No session ID');
  if (!answers?.length) throw new Error('No answers to submit');

  const { data, error } = await supabase.rpc('submit_assessment', {
    p_session_id:        sessionId,
    p_answers:           JSON.stringify(answers),
    p_score_judgement:   Math.min(100, Math.max(0, score_judgement)),
    p_score_numerical:   Math.min(100, Math.max(0, score_numerical)),
    p_score_verbal:      Math.min(100, Math.max(0, score_verbal)),
    p_score_situational: Math.min(100, Math.max(0, score_situational)),
    p_time_taken_seconds: time_taken_seconds,
  });

  if (error) throw new Error(error.message);

  // Store minimal confirmation data for the submitted page
  // No scores stored here — applicants never see their score
  sessionStorage.setItem('novaCS_submission', JSON.stringify({
    submitted:         true,
    time_taken_seconds: time_taken_seconds,
    questions_answered: answers.length,
    submitted_at:      new Date().toISOString()
  }));

  return data;
}
