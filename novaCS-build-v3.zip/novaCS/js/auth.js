/* ═══════════════════════════════════════════════════════════════
   NovaCS — Auth Module
   js/auth.js

   Handles all recruiter authentication securely.
   Applicants are NOT authenticated users — they use access codes.
═══════════════════════════════════════════════════════════════ */

import { supabase } from './supabase-client.js';

// ── SIGN IN ──
// Returns { profile, error }
export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email:    email.trim().toLowerCase(),
    password: password,
  });

  if (error) return { profile: null, error: error.message };

  // Fetch the recruiter's profile + org immediately after auth
  const { data: profile, error: profileError } = await supabase
    .from('recruiter_profiles')
    .select(`
      id,
      full_name,
      email,
      role,
      organisation_id,
      organisations (
        id,
        name,
        slug,
        logo_url,
        accent_color
      )
    `)
    .eq('id', data.user.id)
    .single();

  if (profileError) return { profile: null, error: 'Account found but profile missing. Contact support.' };
  if (!profile.is_active) {
    await supabase.auth.signOut();
    return { profile: null, error: 'Your account has been deactivated. Contact your administrator.' };
  }

  // Update last login
  await supabase
    .from('recruiter_profiles')
    .update({ last_login_at: new Date().toISOString() })
    .eq('id', data.user.id);

  return { profile, error: null };
}


// ── SIGN OUT ──
export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (!error) {
    // Clear any local state
    sessionStorage.clear();
    window.location.href = '/index.html';
  }
}


// ── GET CURRENT SESSION ──
// Returns { session, profile } or null
export async function getSession() {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) return null;

  const { data: profile } = await supabase
    .from('recruiter_profiles')
    .select(`
      id, full_name, email, role, organisation_id,
      organisations ( id, name, slug, logo_url, accent_color )
    `)
    .eq('id', session.user.id)
    .single();

  return { session, profile };
}


// ── REQUIRE AUTH ──
// Call at the top of every protected page
// Redirects to login if no valid session found
export async function requireAuth() {
  const result = await getSession();
  if (!result) {
    window.location.href = '/index.html?reason=not_authenticated';
    return null;
  }
  return result;
}


// ── REQUIRE ROLE ──
// e.g. requireRole('admin') — redirects if insufficient role
export async function requireRole(minRole) {
  const result = await requireAuth();
  if (!result) return null;

  const hierarchy = { recruiter: 1, admin: 2, superadmin: 3 };
  const userLevel = hierarchy[result.profile.role] || 0;
  const required  = hierarchy[minRole] || 99;

  if (userLevel < required) {
    window.location.href = '/pages/error.html?type=forbidden';
    return null;
  }
  return result;
}


// ── PASSWORD RESET REQUEST ──
export async function requestPasswordReset(email) {
  const { error } = await supabase.auth.resetPasswordForEmail(
    email.trim().toLowerCase(),
    { redirectTo: `${window.location.origin}/pages/password-reset.html?step=3` }
  );
  // Always return success to prevent email enumeration attacks
  return { error: null };
}


// ── UPDATE PASSWORD (from reset link) ──
export async function updatePassword(newPassword) {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  return { error: error?.message || null };
}
