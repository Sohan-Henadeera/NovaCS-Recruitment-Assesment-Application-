/* ═══════════════════════════════════════════════════════════════
   NovaCS — Candidates Module
   js/candidates.js

   All candidate reads/writes go through here.
   RLS on Supabase ensures recruiters only ever see their own org.
═══════════════════════════════════════════════════════════════ */

import { supabase } from './supabase-client.js';

// ── GET ALL CANDIDATES FOR CURRENT ORG ──
// RLS handles org scoping automatically
export async function getCandidates({ orderBy = 'created_at', ascending = false } = {}) {
  const { data, error } = await supabase
    .from('candidates')
    .select(`
      id,
      full_name,
      email,
      role_applied,
      stage,
      decision,
      recruiter_notes,
      invited_at,
      created_at,
      assessment_sessions (
        id,
        status,
        score_weighted,
        score_judgement,
        score_numerical,
        score_verbal,
        score_situational,
        passed,
        flagged,
        tab_switch_count,
        time_taken_seconds,
        submitted_at
      )
    `)
    .order(orderBy, { ascending });

  if (error) throw new Error(error.message);

  // Flatten — attach the latest session to each candidate
  return data.map(c => ({
    ...c,
    session: c.assessment_sessions?.[0] || null,
    assessment_sessions: undefined,
  }));
}


// ── GET SINGLE CANDIDATE ──
export async function getCandidate(candidateId) {
  const { data, error } = await supabase
    .from('candidates')
    .select(`
      id, full_name, email, role_applied, stage, decision, recruiter_notes,
      invited_at, created_at, invite_batch_id,
      assessment_sessions (
        id, status, score_weighted, score_judgement, score_numerical,
        score_verbal, score_situational, passed, flagged,
        tab_switch_count, time_taken_seconds, submitted_at,
        questions_answered, threshold_at_submit,
        weight_judgement, weight_numerical, weight_verbal, weight_situational
      ),
      access_codes ( code, status, issued_at, used_at, expires_at )
    `)
    .eq('id', candidateId)
    .single();

  if (error) throw new Error(error.message);
  return data;
}


// ── UPDATE CANDIDATE DECISION ──
export async function updateDecision(candidateId, decision) {
  if (!['none', 'shortlisted', 'rejected'].includes(decision)) {
    throw new Error('Invalid decision value');
  }

  const { error } = await supabase
    .from('candidates')
    .update({ decision })
    .eq('id', candidateId);

  if (error) throw new Error(error.message);

  await supabase.rpc('write_audit_log', {
    p_action:      `candidate.${decision}`,
    p_target_type: 'candidate',
    p_target_id:   candidateId,
    p_metadata:    { decision }
  });
}


// ── UPDATE STAGE ──
export async function updateStage(candidateId, stage) {
  const valid = ['', 'Screening', 'Phone Screen', 'Interview', 'Final Round', 'Offer'];
  if (!valid.includes(stage)) throw new Error('Invalid stage');

  const { error } = await supabase
    .from('candidates')
    .update({ stage })
    .eq('id', candidateId);

  if (error) throw new Error(error.message);
}


// ── SAVE RECRUITER NOTES ──
export async function saveNotes(candidateId, notes) {
  // Sanitise: strip any HTML to prevent stored XSS
  const clean = notes.replace(/<[^>]*>/g, '').substring(0, 5000);

  const { error } = await supabase
    .from('candidates')
    .update({ recruiter_notes: clean })
    .eq('id', candidateId);

  if (error) throw new Error(error.message);
}


// ── CREATE CANDIDATE + ISSUE CODE ──
export async function createCandidateWithCode(orgId, recruiterId, candidateData) {
  const { full_name, email, role_applied, phone_last4, invite_batch_id } = candidateData;

  // Validate phone last 4
  if (phone_last4 && !/^\d{4}$/.test(phone_last4)) {
    throw new Error('phone_last4 must be exactly 4 digits');
  }

  // 1. Insert candidate
  const { data: candidate, error: candError } = await supabase
    .from('candidates')
    .insert({
      organisation_id: orgId,
      full_name:       full_name.trim(),
      email:           email.trim().toLowerCase(),
      role_applied:    role_applied?.trim() || null,
      phone_last4:     phone_last4 || null,
      invite_batch_id: invite_batch_id || null,
      invited_at:      new Date().toISOString(),
    })
    .select('id')
    .single();

  if (candError) {
    if (candError.code === '23505') throw new Error('A candidate with this email already exists for this organisation.');
    throw new Error(candError.message);
  }

  // 2. Generate access code via DB function (handles uniqueness internally)
  const { data: code, error: codeError } = await supabase.rpc('generate_access_code', {
    p_candidate_id:    candidate.id,
    p_organisation_id: orgId,
    p_issued_by:       recruiterId,
    p_expires_at:      null,
  });

  if (codeError) throw new Error(codeError.message);

  await supabase.rpc('write_audit_log', {
    p_action:      'code.issued',
    p_target_type: 'access_code',
    p_target_id:   candidate.id,
    p_metadata:    { email, role_applied, code }
  });

  return { candidateId: candidate.id, code };
}


// ── REVOKE ACCESS CODE ──
export async function revokeCode(codeId) {
  const { error } = await supabase
    .from('access_codes')
    .update({ status: 'revoked' })
    .eq('id', codeId);

  if (error) throw new Error(error.message);

  await supabase.rpc('write_audit_log', {
    p_action:      'code.revoked',
    p_target_type: 'access_code',
    p_target_id:   codeId,
    p_metadata:    {}
  });
}


// ── EXPORT CANDIDATES AS CSV ──
export async function exportCandidatesCSV() {
  const candidates = await getCandidates();

  const headers = [
    'Name', 'Email', 'Role', 'Status', 'Weighted Score',
    'Judgement', 'Numerical', 'Verbal', 'Situational',
    'Pass/Fail', 'Decision', 'Stage', 'Submitted At'
  ];

  const rows = candidates.map(c => {
    const s = c.session;
    return [
      c.full_name,
      c.email,
      c.role_applied || '',
      s?.status || 'invited',
      s?.score_weighted ?? '',
      s?.score_judgement ?? '',
      s?.score_numerical ?? '',
      s?.score_verbal ?? '',
      s?.score_situational ?? '',
      s ? (s.passed ? 'Pass' : 'Fail') : '',
      c.decision,
      c.stage || '',
      s?.submitted_at ? new Date(s.submitted_at).toLocaleDateString('en-GB') : ''
    ].map(v => `"${String(v).replace(/"/g, '""')}"`).join(',');
  });

  const csv = [headers.join(','), ...rows].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `novaCS_candidates_${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
