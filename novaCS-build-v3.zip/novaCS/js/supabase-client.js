/* ═══════════════════════════════════════════════════════════════
   NovaCS — Supabase Client
   js/supabase-client.js

   SECURITY RULES:
   - ANON KEY only — never the service_role key in frontend
   - All sensitive ops go through RLS + SECURITY DEFINER functions
   - No raw SQL from the frontend ever
═══════════════════════════════════════════════════════════════ */

import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

// These are safe to expose — anon key is read-limited by RLS
// Set these as environment variables in Vercel, never hardcode secrets
const SUPABASE_URL  = window.__ENV?.SUPABASE_URL  || 'REPLACE_WITH_YOUR_PROJECT_URL';
const SUPABASE_ANON = window.__ENV?.SUPABASE_ANON_KEY || 'REPLACE_WITH_YOUR_ANON_KEY';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON, {
  auth: {
    autoRefreshToken:    true,
    persistSession:      true,
    detectSessionInUrl:  true,
    storage:             window.localStorage,    // session persisted across tabs
    storageKey:          'novaCS_auth_session',
  },
  global: {
    headers: {
      'X-Client-Info': 'novaCS-web/1.0'
    }
  }
});

// ── Auth state listener ──
// Redirect to login if session expires mid-session
supabase.auth.onAuthStateChange((event, session) => {
  if (event === 'SIGNED_OUT') {
    // Only redirect if on a protected page
    const protectedPaths = ['dashboard', 'candidates', 'candidate-profile', 'invite-manager', 'settings'];
    const onProtected = protectedPaths.some(p => window.location.pathname.includes(p));
    if (onProtected) {
      window.location.href = '/index.html?reason=session_expired';
    }
  }
  if (event === 'TOKEN_REFRESHED') {
    console.log('[NovaCS] Session token refreshed');
  }
});

export default supabase;
