/* ═══════════════════════════════════════════════════════════════
   NovaCS — Contact / Enquiries Module
   js/contact.js

   Public form submission — no auth required.
   RLS allows public INSERT to contact_enquiries only.
   Rate limiting handled via Supabase edge function (future).
═══════════════════════════════════════════════════════════════ */

import { supabase } from './supabase-client.js';

export async function submitEnquiry(formData) {
  const {
    first_name,
    last_name,
    email,
    company_name,
    company_size,
    industry,
    volume_estimate,
    features_wanted,   // array of strings
    notes,
    preferred_contact,
  } = formData;

  // Client-side validation before hitting the DB
  const errors = {};
  if (!first_name?.trim())  errors.first_name  = 'Required';
  if (!last_name?.trim())   errors.last_name   = 'Required';
  if (!email?.trim() || !email.includes('@')) errors.email = 'Valid email required';
  if (!company_name?.trim()) errors.company_name = 'Required';
  if (!company_size)         errors.company_size = 'Required';
  if (!industry)             errors.industry     = 'Required';

  if (Object.keys(errors).length) return { success: false, errors };

  // Sanitise text fields
  const clean = (s) => s?.trim().replace(/<[^>]*>/g, '').substring(0, 500) || null;

  const { error } = await supabase
    .from('contact_enquiries')
    .insert({
      first_name:       clean(first_name),
      last_name:        clean(last_name),
      email:            email.trim().toLowerCase().substring(0, 254),
      company_name:     clean(company_name),
      company_size:     company_size,
      industry:         industry,
      volume_estimate:  volume_estimate || null,
      features_wanted:  features_wanted || [],
      notes:            clean(notes),
      preferred_contact: preferred_contact || 'Email',
    });

  if (error) {
    console.error('[NovaCS] Enquiry submission failed:', error.code);
    return { success: false, errors: { form: 'Something went wrong. Please try again or email us directly.' } };
  }

  return { success: true };
}
