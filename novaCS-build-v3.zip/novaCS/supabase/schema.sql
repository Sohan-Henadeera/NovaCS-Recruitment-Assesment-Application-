-- ═══════════════════════════════════════════════════════════════
-- NovaCS — Complete Supabase Schema
-- Run this entire file in Supabase SQL Editor (in order)
-- ═══════════════════════════════════════════════════════════════

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";


-- ═══════════════════════════════════════════════════════════════
-- 1. ORGANISATIONS
-- Each client company using the NovaCS platform
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE organisations (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name            TEXT NOT NULL,
  slug            TEXT NOT NULL UNIQUE,         -- e.g. "acme-corp" used in URLs
  logo_url        TEXT,                         -- stored in Supabase Storage
  accent_color    TEXT DEFAULT '#2452a0',       -- hex, used in white-label UI
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for slug lookups (used on applicant login dropdown)
CREATE INDEX idx_organisations_slug ON organisations(slug);
CREATE INDEX idx_organisations_active ON organisations(is_active);


-- ═══════════════════════════════════════════════════════════════
-- 2. RECRUITER USERS
-- Linked to Supabase Auth — one recruiter belongs to one org
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE recruiter_profiles (
  id              UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  organisation_id UUID NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
  full_name       TEXT NOT NULL,
  email           TEXT NOT NULL,                -- mirrors auth.users.email
  role            TEXT NOT NULL DEFAULT 'recruiter' CHECK (role IN ('recruiter', 'admin', 'superadmin')),
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at   TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_recruiter_profiles_org ON recruiter_profiles(organisation_id);
CREATE INDEX idx_recruiter_profiles_email ON recruiter_profiles(email);


-- ═══════════════════════════════════════════════════════════════
-- 3. ASSESSMENT CONFIG
-- Per-org scoring weights and settings
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE assessment_configs (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organisation_id       UUID NOT NULL UNIQUE REFERENCES organisations(id) ON DELETE CASCADE,

  -- Category weights (must sum to 1.0 — enforced by check constraint)
  weight_judgement      NUMERIC(4,3) NOT NULL DEFAULT 0.350,
  weight_numerical      NUMERIC(4,3) NOT NULL DEFAULT 0.250,
  weight_verbal         NUMERIC(4,3) NOT NULL DEFAULT 0.200,
  weight_situational    NUMERIC(4,3) NOT NULL DEFAULT 0.200,

  pass_threshold        INTEGER NOT NULL DEFAULT 65 CHECK (pass_threshold BETWEEN 1 AND 100),
  time_limit_minutes    INTEGER NOT NULL DEFAULT 25 CHECK (time_limit_minutes BETWEEN 5 AND 120),
  randomise_questions   BOOLEAN NOT NULL DEFAULT TRUE,
  randomise_options     BOOLEAN NOT NULL DEFAULT TRUE,
  allow_section_intro   BOOLEAN NOT NULL DEFAULT TRUE,

  CONSTRAINT weights_sum_to_one CHECK (
    ROUND((weight_judgement + weight_numerical + weight_verbal + weight_situational)::NUMERIC, 3) = 1.000
  ),

  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- ═══════════════════════════════════════════════════════════════
-- 4. CANDIDATES
-- Personal details of people being assessed
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE candidates (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organisation_id UUID NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,

  -- Identity fields
  full_name       TEXT NOT NULL,
  email           TEXT NOT NULL,
  role_applied    TEXT,                         -- job title they applied for
  phone_last4     CHAR(4),                      -- only last 4 digits, for identity verification

  -- Recruiter-facing fields
  stage           TEXT DEFAULT '' CHECK (stage IN ('', 'Screening', 'Phone Screen', 'Interview', 'Final Round', 'Offer')),
  decision        TEXT DEFAULT 'none' CHECK (decision IN ('none', 'shortlisted', 'rejected')),
  recruiter_notes TEXT DEFAULT '',

  -- Invite tracking
  invited_at      TIMESTAMPTZ,
  invite_batch_id UUID,                         -- links to invite_batches table

  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- One candidate per email per organisation
  CONSTRAINT uq_candidate_email_org UNIQUE (email, organisation_id)
);

CREATE INDEX idx_candidates_org      ON candidates(organisation_id);
CREATE INDEX idx_candidates_email    ON candidates(email);
CREATE INDEX idx_candidates_decision ON candidates(decision);
CREATE INDEX idx_candidates_stage    ON candidates(stage);


-- ═══════════════════════════════════════════════════════════════
-- 5. ACCESS CODES
-- Single-use codes issued to candidates
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE access_codes (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code            TEXT NOT NULL UNIQUE,         -- e.g. "AX7K2M" — 6 char alphanumeric
  candidate_id    UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  organisation_id UUID NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
  issued_by       UUID REFERENCES recruiter_profiles(id) ON DELETE SET NULL,

  status          TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'used', 'expired', 'revoked')),

  issued_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at      TIMESTAMPTZ,                  -- NULL = no expiry set
  used_at         TIMESTAMPTZ,

  -- Code is hashed in storage — plain text only shown once on generation
  code_hash       TEXT GENERATED ALWAYS AS (encode(digest(code, 'sha256'), 'hex')) STORED
);

CREATE INDEX idx_access_codes_code      ON access_codes(code);
CREATE INDEX idx_access_codes_candidate ON access_codes(candidate_id);
CREATE INDEX idx_access_codes_org       ON access_codes(organisation_id);
CREATE INDEX idx_access_codes_status    ON access_codes(status);


-- ═══════════════════════════════════════════════════════════════
-- 6. ASSESSMENT SESSIONS
-- One row per candidate attempt — core scoring table
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE assessment_sessions (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  candidate_id        UUID NOT NULL REFERENCES candidates(id) ON DELETE RESTRICT,
  organisation_id     UUID NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
  access_code_id      UUID NOT NULL UNIQUE REFERENCES access_codes(id) ON DELETE RESTRICT,

  -- Lifecycle
  status              TEXT NOT NULL DEFAULT 'pending'
                      CHECK (status IN ('pending', 'identity_verified', 'in_progress', 'submitted', 'timed_out', 'abandoned')),

  started_at          TIMESTAMPTZ,
  submitted_at        TIMESTAMPTZ,
  time_taken_seconds  INTEGER,

  -- Raw category scores (0-100)
  score_judgement     NUMERIC(5,2),
  score_numerical     NUMERIC(5,2),
  score_verbal        NUMERIC(5,2),
  score_situational   NUMERIC(5,2),

  -- Weighted final score — computed on submission
  score_weighted      NUMERIC(5,2),

  -- Pass/fail — set against org threshold at time of submission
  passed              BOOLEAN,
  threshold_at_submit INTEGER,                  -- snapshot of threshold when scored

  -- Integrity flags
  questions_answered  INTEGER DEFAULT 0,
  tab_switch_count    INTEGER DEFAULT 0,
  flagged             BOOLEAN DEFAULT FALSE,
  flag_reason         TEXT,

  -- Snapshot of weights used (so historic scores are always accurate)
  weight_judgement    NUMERIC(4,3),
  weight_numerical    NUMERIC(4,3),
  weight_verbal       NUMERIC(4,3),
  weight_situational  NUMERIC(4,3),

  ip_address          INET,                     -- hashed/anonymised before storage
  user_agent          TEXT,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sessions_candidate ON assessment_sessions(candidate_id);
CREATE INDEX idx_sessions_org       ON assessment_sessions(organisation_id);
CREATE INDEX idx_sessions_status    ON assessment_sessions(status);
CREATE INDEX idx_sessions_submitted ON assessment_sessions(submitted_at);


-- ═══════════════════════════════════════════════════════════════
-- 7. QUESTION ANSWERS
-- Individual question-level responses per session
-- (Enables per-question analytics in future)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE session_answers (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id      UUID NOT NULL REFERENCES assessment_sessions(id) ON DELETE CASCADE,
  question_id     TEXT NOT NULL,                -- references question bank key
  category        TEXT NOT NULL CHECK (category IN ('judgement', 'numerical', 'verbal', 'situational')),
  answer_given    TEXT,                         -- the option selected
  is_correct      BOOLEAN,
  time_spent_ms   INTEGER,                      -- time on this question in ms
  answered_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_answers_session  ON session_answers(session_id);
CREATE INDEX idx_answers_question ON session_answers(question_id);


-- ═══════════════════════════════════════════════════════════════
-- 8. INVITE BATCHES
-- Groups of candidates invited together
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE invite_batches (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organisation_id UUID NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
  created_by      UUID REFERENCES recruiter_profiles(id) ON DELETE SET NULL,
  name            TEXT NOT NULL,                -- e.g. "Batch 004 — Sales Team"
  deadline        DATE,
  total_invited   INTEGER DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Add FK back to candidates (deferred to avoid circular reference)
ALTER TABLE candidates
  ADD CONSTRAINT fk_candidates_batch
  FOREIGN KEY (invite_batch_id)
  REFERENCES invite_batches(id)
  ON DELETE SET NULL;

CREATE INDEX idx_invite_batches_org ON invite_batches(organisation_id);


-- ═══════════════════════════════════════════════════════════════
-- 9. CONTACT ENQUIRIES
-- Public demo request / contact form submissions
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE contact_enquiries (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  first_name        TEXT NOT NULL,
  last_name         TEXT NOT NULL,
  email             TEXT NOT NULL,
  company_name      TEXT NOT NULL,
  company_size      TEXT,
  industry          TEXT,
  volume_estimate   TEXT,
  features_wanted   TEXT[],                     -- array of selected features
  notes             TEXT,
  preferred_contact TEXT DEFAULT 'Email',
  status            TEXT DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'demo_booked', 'closed_won', 'closed_lost')),
  assigned_to       UUID REFERENCES recruiter_profiles(id) ON DELETE SET NULL,
  submitted_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_enquiries_status ON contact_enquiries(status);
CREATE INDEX idx_enquiries_email  ON contact_enquiries(email);


-- ═══════════════════════════════════════════════════════════════
-- 10. AUDIT LOG
-- Immutable record of all sensitive actions
-- Never update or delete rows in this table
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE audit_log (
  id              BIGSERIAL PRIMARY KEY,
  actor_id        UUID,                         -- recruiter_profile id or NULL for system
  actor_email     TEXT,
  actor_role      TEXT,
  organisation_id UUID,
  action          TEXT NOT NULL,                -- e.g. 'code.issued', 'candidate.rejected', 'session.submitted'
  target_type     TEXT,                         -- e.g. 'candidate', 'access_code', 'session'
  target_id       UUID,
  metadata        JSONB DEFAULT '{}',           -- any extra context
  ip_address      INET,
  occurred_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Only insert allowed on audit_log — no update/delete
CREATE INDEX idx_audit_action   ON audit_log(action);
CREATE INDEX idx_audit_actor    ON audit_log(actor_id);
CREATE INDEX idx_audit_org      ON audit_log(organisation_id);
CREATE INDEX idx_audit_occurred ON audit_log(occurred_at DESC);


-- ═══════════════════════════════════════════════════════════════
-- 11. UPDATED_AT TRIGGERS
-- Automatically update updated_at on every row change
-- ═══════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_organisations_updated_at
  BEFORE UPDATE ON organisations
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_recruiter_profiles_updated_at
  BEFORE UPDATE ON recruiter_profiles
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_assessment_configs_updated_at
  BEFORE UPDATE ON assessment_configs
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_candidates_updated_at
  BEFORE UPDATE ON candidates
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_sessions_updated_at
  BEFORE UPDATE ON assessment_sessions
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_enquiries_updated_at
  BEFORE UPDATE ON contact_enquiries
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();


-- ═══════════════════════════════════════════════════════════════
-- 12. ACCESS CODE GENERATOR FUNCTION
-- Called server-side to generate and insert a new code
-- ═══════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION generate_access_code(
  p_candidate_id    UUID,
  p_organisation_id UUID,
  p_issued_by       UUID,
  p_expires_at      TIMESTAMPTZ DEFAULT NULL
)
RETURNS TEXT AS $$
DECLARE
  v_code TEXT;
  v_exists BOOLEAN;
  v_chars TEXT := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  v_i INTEGER;
BEGIN
  -- Generate a unique 6-char code, retry if collision
  LOOP
    v_code := '';
    FOR v_i IN 1..6 LOOP
      v_code := v_code || substr(v_chars, floor(random() * length(v_chars) + 1)::INT, 1);
    END LOOP;

    SELECT EXISTS(SELECT 1 FROM access_codes WHERE code = v_code) INTO v_exists;
    EXIT WHEN NOT v_exists;
  END LOOP;

  INSERT INTO access_codes (code, candidate_id, organisation_id, issued_by, expires_at)
  VALUES (v_code, p_candidate_id, p_organisation_id, p_issued_by, p_expires_at);

  RETURN v_code;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ═══════════════════════════════════════════════════════════════
-- 13. WEIGHTED SCORE CALCULATOR
-- Called when a session is submitted
-- ═══════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION calculate_weighted_score(p_session_id UUID)
RETURNS NUMERIC AS $$
DECLARE
  v_session assessment_sessions%ROWTYPE;
  v_score   NUMERIC;
BEGIN
  SELECT * INTO v_session FROM assessment_sessions WHERE id = p_session_id;

  v_score := ROUND(
    (v_session.score_judgement   * v_session.weight_judgement   +
     v_session.score_numerical   * v_session.weight_numerical   +
     v_session.score_verbal      * v_session.weight_verbal      +
     v_session.score_situational * v_session.weight_situational)::NUMERIC,
    2
  );

  -- Update the session row
  UPDATE assessment_sessions
  SET score_weighted = v_score,
      passed = (v_score >= v_session.threshold_at_submit)
  WHERE id = p_session_id;

  RETURN v_score;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ═══════════════════════════════════════════════════════════════
-- 14. ROW LEVEL SECURITY (RLS)
-- The most important part — controls who can see what data
-- ═══════════════════════════════════════════════════════════════

-- Enable RLS on every table
ALTER TABLE organisations        ENABLE ROW LEVEL SECURITY;
ALTER TABLE recruiter_profiles   ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessment_configs   ENABLE ROW LEVEL SECURITY;
ALTER TABLE candidates           ENABLE ROW LEVEL SECURITY;
ALTER TABLE access_codes         ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessment_sessions  ENABLE ROW LEVEL SECURITY;
ALTER TABLE session_answers      ENABLE ROW LEVEL SECURITY;
ALTER TABLE invite_batches       ENABLE ROW LEVEL SECURITY;
ALTER TABLE contact_enquiries    ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log            ENABLE ROW LEVEL SECURITY;

-- ── HELPER: get current recruiter's org ──
CREATE OR REPLACE FUNCTION current_org_id()
RETURNS UUID AS $$
  SELECT organisation_id
  FROM recruiter_profiles
  WHERE id = auth.uid()
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- ── HELPER: get current recruiter's role ──
CREATE OR REPLACE FUNCTION current_recruiter_role()
RETURNS TEXT AS $$
  SELECT role
  FROM recruiter_profiles
  WHERE id = auth.uid()
$$ LANGUAGE sql SECURITY DEFINER STABLE;


-- ORGANISATIONS
-- Recruiters can only see their own org
CREATE POLICY "Recruiter sees own org"
  ON organisations FOR SELECT
  USING (id = current_org_id());

-- Only superadmins can insert/update orgs
CREATE POLICY "Superadmin manages orgs"
  ON organisations FOR ALL
  USING (current_recruiter_role() = 'superadmin');


-- RECRUITER PROFILES
-- Recruiters see only profiles in their org
CREATE POLICY "Recruiter sees own profile and org teammates"
  ON recruiter_profiles FOR SELECT
  USING (organisation_id = current_org_id());

-- Recruiters can update their own profile only
CREATE POLICY "Recruiter updates own profile"
  ON recruiter_profiles FOR UPDATE
  USING (id = auth.uid());


-- ASSESSMENT CONFIGS
-- Recruiters see their org config
CREATE POLICY "Recruiter sees own config"
  ON assessment_configs FOR SELECT
  USING (organisation_id = current_org_id());

-- Admin+ can update config
CREATE POLICY "Admin updates config"
  ON assessment_configs FOR UPDATE
  USING (organisation_id = current_org_id()
    AND current_recruiter_role() IN ('admin', 'superadmin'));


-- CANDIDATES
-- Recruiters see only their org's candidates
CREATE POLICY "Recruiter sees own org candidates"
  ON candidates FOR SELECT
  USING (organisation_id = current_org_id());

CREATE POLICY "Recruiter inserts candidates"
  ON candidates FOR INSERT
  WITH CHECK (organisation_id = current_org_id());

CREATE POLICY "Recruiter updates candidates"
  ON candidates FOR UPDATE
  USING (organisation_id = current_org_id());

-- Only admins can delete candidates
CREATE POLICY "Admin deletes candidates"
  ON candidates FOR DELETE
  USING (organisation_id = current_org_id()
    AND current_recruiter_role() IN ('admin', 'superadmin'));


-- ACCESS CODES
-- Recruiters see only their org's codes
CREATE POLICY "Recruiter sees own org codes"
  ON access_codes FOR SELECT
  USING (organisation_id = current_org_id());

CREATE POLICY "Recruiter issues codes"
  ON access_codes FOR INSERT
  WITH CHECK (organisation_id = current_org_id());

-- Only the system function can update code status (via SECURITY DEFINER)
-- Recruiters can revoke codes
CREATE POLICY "Recruiter revokes codes"
  ON access_codes FOR UPDATE
  USING (organisation_id = current_org_id());


-- ASSESSMENT SESSIONS
-- Recruiters see sessions for their org only
CREATE POLICY "Recruiter sees own org sessions"
  ON assessment_sessions FOR SELECT
  USING (organisation_id = current_org_id());

-- Applicants cannot directly read/write sessions — all writes go through
-- SECURITY DEFINER functions only. No public SELECT policy = no access.


-- SESSION ANSWERS
-- Only recruiters in the same org can read answers
CREATE POLICY "Recruiter reads own org answers"
  ON session_answers FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM assessment_sessions s
      WHERE s.id = session_id
        AND s.organisation_id = current_org_id()
    )
  );


-- INVITE BATCHES
CREATE POLICY "Recruiter sees own org batches"
  ON invite_batches FOR SELECT
  USING (organisation_id = current_org_id());

CREATE POLICY "Recruiter creates batches"
  ON invite_batches FOR INSERT
  WITH CHECK (organisation_id = current_org_id());


-- CONTACT ENQUIRIES
-- Only superadmins can read enquiries (they land from the public form)
CREATE POLICY "Superadmin reads enquiries"
  ON contact_enquiries FOR SELECT
  USING (current_recruiter_role() = 'superadmin');

-- Public INSERT allowed (the contact form is unauthenticated)
CREATE POLICY "Public submits enquiry"
  ON contact_enquiries FOR INSERT
  WITH CHECK (TRUE);


-- AUDIT LOG
-- Superadmins can read — nobody can insert directly (use function)
CREATE POLICY "Superadmin reads audit log"
  ON audit_log FOR SELECT
  USING (current_recruiter_role() = 'superadmin');

-- Admins can read their own org's audit entries
CREATE POLICY "Admin reads own org audit"
  ON audit_log FOR SELECT
  USING (organisation_id = current_org_id()
    AND current_recruiter_role() IN ('admin', 'superadmin'));


-- ═══════════════════════════════════════════════════════════════
-- 15. AUDIT LOG INSERT FUNCTION
-- The only way to write to audit_log — called from other functions
-- ═══════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION write_audit_log(
  p_action        TEXT,
  p_target_type   TEXT    DEFAULT NULL,
  p_target_id     UUID    DEFAULT NULL,
  p_metadata      JSONB   DEFAULT '{}',
  p_ip_address    INET    DEFAULT NULL
)
RETURNS VOID AS $$
DECLARE
  v_actor   recruiter_profiles%ROWTYPE;
BEGIN
  SELECT * INTO v_actor FROM recruiter_profiles WHERE id = auth.uid();

  INSERT INTO audit_log (
    actor_id, actor_email, actor_role,
    organisation_id, action,
    target_type, target_id,
    metadata, ip_address
  ) VALUES (
    auth.uid(), v_actor.email, v_actor.role,
    v_actor.organisation_id, p_action,
    p_target_type, p_target_id,
    p_metadata, p_ip_address
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ═══════════════════════════════════════════════════════════════
-- 16. STORAGE BUCKETS
-- Run these in Supabase Dashboard → Storage, or via SQL
-- ═══════════════════════════════════════════════════════════════

-- Organisation logos (private — served via signed URLs)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'org-logos',
  'org-logos',
  FALSE,
  2097152,   -- 2MB max
  ARRAY['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml']
) ON CONFLICT DO NOTHING;

-- Only recruiters in the org can upload/read their logo
CREATE POLICY "Recruiter manages own org logo"
  ON storage.objects FOR ALL
  USING (
    bucket_id = 'org-logos'
    AND (storage.foldername(name))[1] = current_org_id()::TEXT
  );


-- ═══════════════════════════════════════════════════════════════
-- 17. SEED DATA — NovaCS internal org (run once)
-- ═══════════════════════════════════════════════════════════════

-- Insert the NovaCS admin organisation
INSERT INTO organisations (id, name, slug, accent_color)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'NovaCS',
  'novaCS',
  '#2452a0'
) ON CONFLICT DO NOTHING;

-- Insert a demo organisation (for testing)
INSERT INTO organisations (id, name, slug, accent_color)
VALUES (
  '00000000-0000-0000-0000-000000000002',
  'Acme Corp',
  'acme-corp',
  '#1e3a5f'
) ON CONFLICT DO NOTHING;

-- Insert default assessment config for demo org
INSERT INTO assessment_configs (organisation_id)
VALUES ('00000000-0000-0000-0000-000000000002')
ON CONFLICT DO NOTHING;
